from fastapi import FastAPI, Request
from pydantic import BaseModel
from models import load_model, predict_category

# Load model at startup
model = load_model()

app = FastAPI(title="Support Email Classifier")

class EmailInput(BaseModel):
    email_body: str

@app.post("/classify")
async def classify_email(input_data: EmailInput):
    result = predict_category(input_data.email_body, model)
    return result
