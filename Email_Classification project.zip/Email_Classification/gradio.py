from gradio import Textbox, Interface
from transformers import pipeline

# Load your trained model (this can be a model from Hugging Face or your own model)
model = pipeline("text-classification", model="model/email_classifier.joblib")

# Define the function to predict the category of the email
def classify_email(email_text):
    result = model(email_text)
    return result[0]['label']

# Create Gradio interface
iface = Interface(fn=classify_email,
                  inputs=Textbox(lines=2, placeholder="Enter email text here..."),
                  outputs="text",
                  title="Email Classification App",
                  description="Classify emails into predefined categories")

# Launch the interface
iface.launch()
