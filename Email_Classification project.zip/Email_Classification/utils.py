import re
import spacy

# Load spaCy model for NER
nlp = spacy.load("en_core_web_sm")

# Regex-based PII patterns
REGEX_PATTERNS = {
    'email': r'[\w\.-]+@[\w\.-]+',
    'phone_number': r'\b\d{10}\b',
    'dob': r'\b\d{2}[/-]\d{2}[/-]\d{4}\b',
    'aadhar_num': r'\b\d{4}\s\d{4}\s\d{4}\b',
    'credit_debit_no': r'\b(?:\d[ -]*?){13,16}\b',
    'cvv_no': r'\b\d{3}\b',
    'expiry_no': r'\b(0[1-9]|1[0-2])/(\d{2}|\d{4})\b'
}

def mask_pii(text):
    entities = []
    masked_text = text

    # Apply regex-based patterns
    for label, pattern in REGEX_PATTERNS.items():
        for match in re.finditer(pattern, masked_text):
            start, end = match.start(), match.end()
            original_entity = masked_text[start:end]
            entities.append({
                "position": [start, end],
                "classification": label,
                "entity": original_entity
            })
            masked_text = masked_text.replace(original_entity, f"[{label}]")

    # Apply spaCy-based NER for full_name
    doc = nlp(text)
    for ent in doc.ents:
        if ent.label_ == "PERSON":
            original_entity = ent.text
            start = masked_text.find(original_entity)
            end = start + len(original_entity)
            if start != -1:
                entities.append({
                    "position": [start, end],
                    "classification": "full_name",
                    "entity": original_entity
                })
                masked_text = masked_text.replace(original_entity, "[full_name]")

    return masked_text, entities
