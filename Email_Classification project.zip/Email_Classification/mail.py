import pandas as pd
import re
import spacy
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
nlp = spacy.load("en_core_web_sm")

# Load dataset
data = pd.read_csv("data/combined_emails_with_natural_pii.csv")
X_raw = data['email']
y = data['type']

# --- Helper function to mask PII ---
def mask_pii(text):
    entities = []
    original_text = text
    masked_text = text

    # Regex patterns
    regex_patterns = {
        'email': r'[\w\.-]+@[\w\.-]+',
        'phone_number': r'\b\d{10}\b',
        'dob': r'\b\d{2}[/-]\d{2}[/-]\d{4}\b',
        'aadhar_num': r'\b\d{4}\s\d{4}\s\d{4}\b',
        'credit_debit_no': r'\b(?:\d[ -]*?){13,16}\b',
        'cvv_no': r'\b\d{3}\b',
        'expiry_no': r'\b(0[1-9]|1[0-2])/(\d{2}|\d{4})\b'
    }

    for label, pattern in regex_patterns.items():
        for match in re.finditer(pattern, masked_text):
            start, end = match.start(), match.end()
            original_entity = masked_text[start:end]
            entities.append({
                "position": [start, end],
                "classification": label,
                "entity": original_entity
            })
            masked_text = masked_text.replace(original_entity, f"[{label}]")

    # spaCy NER for full_name
    doc = nlp(original_text)
    for ent in doc.ents:
        if ent.label_ == "PERSON":
            original_entity = ent.text
            start = masked_text.find(original_entity)
            end = start + len(original_entity)
            if start != -1:
                entities.append({
                    "position": [start, end],
                    "classification": "full_name",
                    "entity": original_entity
                })
                masked_text = masked_text.replace(original_entity, "[full_name]")

    return masked_text, entities

# --- Mask all emails and keep original ---
masked_emails = []
entity_list = []
for email in X_raw:
    masked, ents = mask_pii(email)
    masked_emails.append(masked)
    entity_list.append(ents)

X = pd.Series(masked_emails)

# --- Split Data ---
X_train, X_test, y_train, y_test, ents_train, ents_test = train_test_split(
    X, y, entity_list, test_size=0.2, random_state=42
)

# --- Train Classifier ---
model = make_pipeline(TfidfVectorizer(), MultinomialNB())
model.fit(X_train, y_train)

# --- Save Model ---
joblib.dump(model, "model/email_classifier.joblib")

# --- Evaluate ---
y_pred = model.predict(X_test)
print(classification_report(y_test, y_pred))

# --- Example Inference ---
def classify_new_email(email_text):
    masked, entities = mask_pii(email_text)
    category = model.predict([masked])[0]
    return {
        "input_email_body": email_text,
        "list_of_masked_entities": entities,
        "masked_email": masked,
        "category_of_the_email": category
    }

# Try it
sample = "Hi, I am Ramesh Kumar. My email is ramesh.k@example.com and card number is 4111 1111 1111 1111. Help with billing."
print(classify_new_email(sample))
